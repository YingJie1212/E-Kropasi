<?php
session_start();
require_once "../classes/Product.php";
require_once "../classes/Package.php";
require_once "../classes/ProductOptionGroup.php";
require_once "../classes/ProductOptionValue.php";
require_once "../classes/ProductPackage.php";
require_once "../classes/Cart.php";


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$productObj = new Product();
$packageObj = new Package();
$optionGroupObj = new ProductOptionGroup();
$optionValueObj = new ProductOptionValue();
$productPackageObj = new ProductPackage();

$cartObj = new Cart();


$products = $productObj->getAll();
$packages = $packageObj->getAllPackages();

// Handle add to cart submission
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart = new Cart();
    $user_id = $_SESSION['user_id'];
    $item_id = (int) ($_POST['item_id'] ?? 0);
    $item_type = $_POST['item_type'] ?? 'product';
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));

    $selected_options = $_POST['options'] ?? [];

    $success = $cart->addItem($user_id, $item_id, $item_type, $quantity, $selected_options);

    if ($success) {
        header("Location: cart.php?added=1");
    } else {
        echo "Failed to add to cart.";
    }
}

// Handle add to cart submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $item_type = $_POST['item_type']; // 'product' or 'package'
    $item_id = intval($_POST['item_id']);
    $quantity = max(1, intval($_POST['quantity'] ?? 1));
    $selected_options = $_POST['options'] ?? []; // associative array option_group => option_value

    // Simple cart item structure
    $cart_item = [
        'type' => $item_type,
        'id' => $item_id,
        'quantity' => $quantity,
        'options' => $selected_options,
    ];

    // Add to session cart
    $_SESSION['cart'][] = $cart_item;

    // Redirect to avoid resubmission
    header("Location: products.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Products & Packages</title>
    <style>
        :root {
            --primary-beige: #f5f5f0;
            --secondary-beige: #e8e6df;
            --accent-beige: #d8d5cd;
            --text-color: #333;
            --border-color: #c4beb5;
            --button-color: #8b7d70;
            --button-hover: #6b5d52;
            --header-bg: #e8e6df;
            --row-even: #f9f8f6;
            --row-odd: #ffffff;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--primary-beige);
            color: var(--text-color);
            line-height: 1.6;
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        h1 {
            font-weight: 500;
            color: #5a4e42;
            font-size: 28px;
        }
        
        .cart-link {
            color: white;
            background-color: var(--button-color);
            text-decoration: none;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 4px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }
        
        .cart-link:hover {
            background-color: var(--button-hover);
        }
        
        .search-container {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        
        .search-input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
        }
        
        .search-button {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .products-table th {
            background-color: var(--header-bg);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #5a4e42;
            border-bottom: 2px solid var(--border-color);
        }
        
        .products-table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }
        
        .products-table tr:nth-child(even) {
            background-color: var(--row-even);
        }
        
        .products-table tr:nth-child(odd) {
            background-color: var(--row-odd);
        }
        
        .products-table tr:hover {
            background-color: var(--secondary-beige);
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }
        
        .product-name {
            font-weight: 600;
            color: #5a4e42;
            margin-bottom: 5px;
        }
        
        .product-description {
            font-size: 13px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .product-price {
            font-weight: 600;
            color: #2b8a3e;
            font-size: 16px;
        }
        
        .option-group {
            margin-bottom: 10px;
        }
        
        .option-label {
            display: block;
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 3px;
            color: #5a4e42;
        }
        
        .option-select {
            width: 100%;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            font-size: 13px;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 10px 0;
        }
        
        .quantity-input {
            width: 60px;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            text-align: center;
        }
        
        .add-to-cart {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .add-to-cart:hover {
            background-color: var(--button-hover);
        }
        
        .package-contents {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        
        .package-contents ul {
            margin: 5px 0 0 15px;
            padding: 0;
        }
        
        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            background-color: #e6f7e6;
            color: #2b8a3e;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Available Products & Packages</h1>
        <a href="cart.php" class="cart-link">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
            </svg>
            View Cart
        </a>
    </div>

    <div class="search-container">
        <input type="text" class="search-input" placeholder="Search products by name, description...">
        <button class="search-button">Search</button>
    </div>

    <table class="products-table">
        <thead>
            <tr>
                <th style="width: 100px;">Image</th>
                <th>Product Details</th>
                <th style="width: 150px;">Options</th>
                <th style="width: 120px;">Price</th>
                <th style="width: 150px;">Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Individual Products -->
            <?php foreach ($products as $product): ?>
                <tr>
                    <td>
                        <?php if (!empty($product['image'])): ?>
                            <img src="../uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image">
                        <?php else: ?>
                            <img src="../assets/default.jpg" alt="No image available" class="product-image">
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-description"><?= htmlspecialchars($product['description']) ?></div>
                        <div class="status-badge">In stock</div>
                    </td>
                    <td>
                        <form method="POST" action="products.php">
                            <input type="hidden" name="item_type" value="product">
                            <input type="hidden" name="item_id" value="<?= $product['id'] ?>">
                            
                            <?php
                            $optionGroups = $optionGroupObj->getByProduct($product['id']);
                            foreach ($optionGroups as $group):
                                $values = $optionValueObj->getByGroup($group['id']);
                            ?>
                                <div class="option-group">
                                    <label class="option-label"><?= htmlspecialchars($group['name']) ?></label>
                                    <select class="option-select" name="options[<?= htmlspecialchars($group['name']) ?>]" required>
                                        <option value="">Select <?= htmlspecialchars($group['name']) ?></option>
                                        <?php foreach ($values as $val): ?>
                                            <option value="<?= htmlspecialchars($val['value']) ?>"><?= htmlspecialchars($val['value']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endforeach; ?>
                    </td>
                    <td class="product-price">₱<?= number_format($product['price'], 2) ?></td>
                    <td>
                        <div class="quantity-control">
                            <label>Qty:</label>
                            <input type="number" class="quantity-input" name="quantity" value="1" min="1" required>
                        </div>
                        <button type="submit" name="add_to_cart" class="add-to-cart">Add to Cart</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>

            <!-- Packages -->
            <?php foreach ($packages as $package): ?>
                <tr>
                    <td>
                        <?php if (!empty($package['image'])): ?>
                            <img src="../uploads/<?= htmlspecialchars($package['image']) ?>" alt="<?= htmlspecialchars($package['name']) ?>" class="product-image">
                        <?php else: ?>
                            <img src="../assets/default.jpg" alt="No image available" class="product-image">
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="product-name"><?= htmlspecialchars($package['name']) ?> <span style="font-size:12px; color:#8b7d70;">(Package)</span></div>
                        <div class="product-description"><?= htmlspecialchars($package['description']) ?></div>
                        <div class="package-contents">
                            <strong>Includes:</strong>
                            <ul>
                                <?php
                                $contents = $productPackageObj->getByPackageId($package['id']);
                                foreach ($contents as $item):
                                    $prod = $productObj->getById($item['product_id']);
                                ?>
                                    <li><?= htmlspecialchars($prod['name']) ?> x <?= intval($item['quantity']) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </td>
                    <td>
                        <form method="POST" action="products.php">
                            <input type="hidden" name="item_type" value="package">
                            <input type="hidden" name="item_id" value="<?= $package['id'] ?>">

                            <?php
                            $productsInPackage = $packageObj->getProductsInPackage($package['id']);
                            foreach ($productsInPackage as $productItem):
                                $productId = $productItem['product_id'];
                                $productName = $productItem['name'];
                                $productImage = $productItem['image'];
                                if (!empty($productItem['options_group'])):
                            ?>
                                <div style="margin-bottom: 10px; font-size:12px; font-weight:500;"><?= htmlspecialchars($productName) ?>:</div>
                                <?php
                                    foreach ($productItem['options_group'] as $group):
                                        $groupName = $group['name'];
                                        $groupOptions = $group['options'];
                                ?>
                                    <div class="option-group">
                                        <label class="option-label"><?= htmlspecialchars($groupName) ?></label>
                                        <select class="option-select" name="options[<?= $productId ?>][<?= htmlspecialchars($groupName) ?>]" required>
                                            <option value="">Select <?= htmlspecialchars($groupName) ?></option>
                                            <?php foreach ($groupOptions as $opt): ?>
                                                <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php
                                    endforeach;
                                endif;
                            endforeach;
                            ?>
                    </td>
                    <td class="product-price">₱<?= number_format($package['price'], 2) ?></td>
                    <td>
                        <div class="quantity-control">
                            <label>Qty:</label>
                            <input type="number" class="quantity-input" name="quantity" value="1" min="1" required>
                        </div>
                        <button type="submit" name="add_to_cart" class="add-to-cart">Add to Cart</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>