<?php
require_once "../classes/DB.php";
require_once "../classes/User.php";
session_start();

// Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit;
}

$db = new DB();
$user = new User($db);
$student = $user->getByStudentId($_SESSION['student_id']);

if (!$student) {
    echo "User not found.";
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updatedData = [
        'name' => trim($_POST['name']),
        'class_name' => trim($_POST['class_name']),
        'phone' => trim($_POST['phone']),
        'parent_name' => trim($_POST['parent_name']),
        'parent_phone' => trim($_POST['parent_phone']),
        'profile_image' => $student['profile_image'], // default to existing image
    ];

    // Handle password update if provided
if (!empty($_POST['new_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword !== $confirmPassword) {
        $errors[] = "New password and confirm password do not match.";
    } elseif (
        strlen($newPassword) < 8 ||
        !preg_match('/[A-Z]/', $newPassword) ||
        !preg_match('/[a-z]/', $newPassword) ||
        !preg_match('/[0-9]/', $newPassword)
    ) {
        $errors[] = "Password must be at least 8 characters long and include uppercase, lowercase, and a number.";
    } else {
        // If valid, hash it and add to update array
        $updatedData['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
    }
}

    // Handle new profile image if uploaded
    if (!empty($_FILES['profile_image']['name'])) {
        $uploadDir = "../uploads/";
        $fileName = basename($_FILES['profile_image']['name']);
        $targetPath = $uploadDir . time() . "_" . $fileName;

        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetPath)) {
            $updatedData['profile_image'] = basename($targetPath);
        } else {
            $errors[] = "Image upload failed.";
        }
    }

    if (empty($errors)) {
        if ($user->updateProfile($_SESSION['student_id'], $updatedData)) {
            $success = true;
            $student = $user->getByStudentId($_SESSION['student_id']); // Refresh data
        } else {
            $errors[] = "Update failed.";
        }
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <style>
        :root {
            --primary-color: #e6f2ff;
            --secondary-color: #cce6ff;
            --accent-color: #99ccff;
            --text-color: #333;
            --success-color: #4CAF50;
            --error-color: #f44336;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f9ff;
            color: var(--text-color);
            line-height: 1.6;
            padding: 20px;
        }
        
        .container {
            max-width: 600px;
            margin: 30px auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        h2 {
            text-align: center;
            color: #0066cc;
            margin-bottom: 25px;
            font-weight: 600;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        
        input[type="text"],
        input[type="password"],
        input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--accent-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(153, 204, 255, 0.2);
        }
        
        .btn {
            background-color: #4da6ff;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #3399ff;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        
        .alert-success {
            background-color: #e6ffe6;
            color: var(--success-color);
            border: 1px solid #b3e6b3;
        }
        
        .alert-error {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #4da6ff;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .profile-image-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin: 10px auto;
            display: block;
            border: 3px solid var(--secondary-color);
        }
        
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        
        .file-input-wrapper input[type="file"] {
            position: absolute;
            font-size: 100px;
            opacity: 0;
            right: 0;
            top: 0;
            cursor: pointer;
        }
        
        .file-input-label {
            display: block;
            padding: 10px;
            background-color: var(--primary-color);
            border: 1px dashed var(--accent-color);
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .file-input-label:hover {
            background-color: var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Profile</h2>

        <?php if ($success): ?>
            <div class="alert alert-success">
                Profile updated successfully!
            </div>
        <?php endif; ?>

        <?php foreach ($errors as $error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data">
            <?php if ($student['profile_image']): ?>
                <img src="../uploads/<?= htmlspecialchars($student['profile_image']) ?>" class="profile-image-preview" id="imagePreview">
            <?php else: ?>
                <div class="profile-image-preview" id="imagePreview" style="background-color: var(--primary-color); display: flex; justify-content: center; align-items: center;">
                    <span style="color: var(--accent-color);">No Image</span>
                </div>
            <?php endif; ?>
            
            <div class="form-group">
                <div class="file-input-wrapper">
                    <label class="file-input-label" for="profileImage">Choose Profile Image</label>
                    <input type="file" name="profile_image" id="profileImage" onchange="previewImage(this)">
                </div>
            </div>
            
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="class_name">Class Name:</label>
                <input type="text" id="class_name" name="class_name" value="<?= htmlspecialchars($student['class_name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="parent_name">Parent Name:</label>
                <input type="text" id="parent_name" name="parent_name" value="<?= htmlspecialchars($student['parent_name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="parent_phone">Parent Phone:</label>
                <input type="text" id="parent_phone" name="parent_phone" value="<?= htmlspecialchars($student['parent_phone']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="new_password">New Password (leave blank to keep current):</label>
                <input type="password" id="new_password" name="new_password">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" id="confirm_password" name="confirm_password">
            </div>
            
            <button type="submit" class="btn">Update Profile</button>
        </form>

        <a href="profile.php" class="back-link">Back to Profile</a>
    </div>

    <script>
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            const file = input.files[0];
            const reader = new FileReader();
            
            reader.onloadend = function() {
                if (preview.tagName === 'IMG') {
                    preview.src = reader.result;
                } else {
                    // If it was the placeholder div, replace with img
                    const newPreview = document.createElement('img');
                    newPreview.src = reader.result;
                    newPreview.className = 'profile-image-preview';
                    newPreview.id = 'imagePreview';
                    preview.parentNode.replaceChild(newPreview, preview);
                }
            }
            
            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>