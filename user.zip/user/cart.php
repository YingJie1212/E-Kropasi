<?php
session_start();
require_once "../classes/Cart.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart = new Cart();

// Handle updates/removals
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cart_id = (int) ($_POST['cart_id'] ?? 0);
    $quantity = (int) ($_POST['quantity'] ?? 1);
    $selected_options = $_POST['selected_options'] ?? [];

    if ($action === 'update' && $quantity > 0) {
        $cart->updateQuantityAndOptions($cart_id, $user_id, $quantity, $selected_options);
    } elseif ($action === 'remove') {
        $cart->removeItem($cart_id, $user_id);
    }

    header("Location: cart.php");
    exit;
}

$items = $cart->getItemsByUser($user_id);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Shopping Cart</title>
    <style>
        :root {
            --primary-beige: #f5f5f0;
            --secondary-beige: #e8e6df;
            --accent-beige: #d8d5cd;
            --text-color: #333;
            --border-color: #c4beb5;
            --button-color: #8b7d70;
            --button-hover: #6b5d52;
            --header-bg: #e8e6df;
            --row-even: #f9f8f6;
            --row-odd: #ffffff;
            --highlight-color: #f0e6d2;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--primary-beige);
            color: var(--text-color);
            line-height: 1.6;
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        h1 {
            font-weight: 500;
            color: #5a4e42;
            font-size: 28px;
        }
        
        .continue-shopping {
            color: var(--button-color);
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s;
        }
        
        .continue-shopping:hover {
            color: var(--button-hover);
            text-decoration: underline;
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .cart-table th {
            background-color: var(--header-bg);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #5a4e42;
            border-bottom: 2px solid var(--border-color);
        }
        
        .cart-table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }
        
        .cart-table tr:nth-child(even) {
            background-color: var(--row-even);
        }
        
        .cart-table tr:nth-child(odd) {
            background-color: var(--row-odd);
        }
        
        .cart-table tr:hover {
            background-color: var(--highlight-color);
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            margin-right: 10px;
        }
        
        .product-info {
            display: flex;
            align-items: center;
        }
        
        .product-name {
            font-weight: 600;
            color: #5a4e42;
            margin-bottom: 5px;
        }
        
        .product-type {
            font-size: 12px;
            color: #8b7d70;
            margin-left: 5px;
        }
        
        .option-group {
            margin-bottom: 8px;
        }
        
        .option-label {
            display: block;
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 3px;
            color: #5a4e42;
        }
        
        .option-select {
            width: 100%;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            font-size: 13px;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 8px 0;
        }
        
        .quantity-input {
            width: 60px;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            text-align: center;
        }
        
        .action-button {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .action-button:hover {
            background-color: var(--button-hover);
        }
        
        .remove-button {
            background-color: #c45656;
        }
        
        .remove-button:hover {
            background-color: #a33d3d;
        }
        
        .checkout-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }
        
        .total-price {
            font-size: 18px;
            font-weight: 600;
            color: #5a4e42;
        }
        
        .checkout-button {
            background-color: #5a8f5a;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: 500;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .checkout-button:hover {
            background-color: #487a48;
        }
        
        .empty-cart {
            text-align: center;
            padding: 40px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .empty-cart-icon {
            font-size: 48px;
            color: #c4beb5;
            margin-bottom: 20px;
        }
        
        .empty-cart-message {
            font-size: 18px;
            color: #5a4e42;
            margin-bottom: 20px;
        }
        
        .select-checkbox {
            transform: scale(1.3);
            margin: 0 auto;
            display: block;
        }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Your Shopping Cart</h1>
        <a href="products.php" class="continue-shopping">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Continue Shopping
        </a>
    </div>

    <?php if (empty($items)): ?>
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <div class="empty-cart-message">Your cart is empty</div>
            <a href="products.php" class="action-button">Browse Products</a>
        </div>
    <?php else: ?>
        <form method="POST" action="checkout.php">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th style="width: 40px;"></th>
                        <th>Product</th>
                        <th style="width: 100px;">Unit Price</th>
                        <th style="width: 250px;">Options & Quantity</th>
                        <th style="width: 100px;">Total</th>
                        <th style="width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $grandTotal = 0;
                foreach ($items as $item): 
                    $itemTotal = $item['price'] * $item['quantity'];
                    $grandTotal += $itemTotal;
                ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="selected_items[]" value="<?= $item['id'] ?>" class="select-checkbox">
                        </td>
                        <td>
                            <div class="product-info">
                                <?php if (!empty($item['display_images'])): ?>
                                    <img src="../uploads/<?= htmlspecialchars($item['display_images'][0]) ?>" class="product-image">
                                <?php else: ?>
                                    <img src="../assets/default.jpg" class="product-image">
                                <?php endif; ?>
                                <div>
                                    <div class="product-name">
                                        <?= htmlspecialchars($item['display_name'] ?? 'Unknown') ?>
                                        <span class="product-type">(<?= $item['item_type'] ?>)</span>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>₱<?= number_format($item['price'], 2) ?></td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                                <?php
                                $selectedOptions = $item['selected_options'] ?? [];

                                if ($item['item_type'] === 'product') {
                                    $optionGroups = $cart->getOptionGroupsWithValues($item['item_id']);
                                    foreach ($optionGroups as $group):
                                        $groupName = $group['group_name'];
                                        $selectedId = $selectedOptions[$groupName] ?? null;
                                ?>
                                    <div class="option-group">
                                        <label class="option-label"><?= htmlspecialchars($groupName) ?></label>
                                        <select class="option-select" name="selected_options[<?= htmlspecialchars($groupName) ?>]">
                                            <?php foreach ($group['options'] as $opt): ?>
                                                <option value="<?= $opt['id'] ?>" <?= ($opt['id'] == $selectedId) ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($opt['value']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php
                                    endforeach;
                                } elseif ($item['item_type'] === 'package') {
                                    $packageOptions = $cart->getOptionsForPackage($item['item_id']);
                                    foreach ($packageOptions as $product_id => $product):
                                        echo "<div style='font-weight:500; margin:8px 0 4px;'>" . htmlspecialchars($product['product_name']) . "</div>";
                                        foreach ($product['option_groups'] as $group):
                                            $groupName = $group['group_name'];
                                            $selectedId = $selectedOptions[$product_id][$groupName] ?? null;
                                ?>
                                        <div class="option-group">
                                            <label class="option-label"><?= htmlspecialchars($groupName) ?></label>
                                            <select class="option-select" name="selected_options[<?= $product_id ?>][<?= htmlspecialchars($groupName) ?>]">
                                                <?php foreach ($group['options'] as $opt): ?>
                                                    <option value="<?= $opt['id'] ?>" <?= ($opt['id'] == $selectedId) ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($opt['value']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                <?php
                                        endforeach;
                                    endforeach;
                                }
                                ?>
                                <div class="quantity-control">
                                    <label>Qty:</label>
                                    <input type="number" class="quantity-input" name="quantity" value="<?= $item['quantity'] ?>" min="1">
                                    <button type="submit" class="action-button">Update</button>
                                </div>
                            </form>
                        </td>
                        <td>₱<?= number_format($itemTotal, 2) ?></td>
                        <td>
                            <form method="POST" action="cart.php" onsubmit="return confirm('Remove this item from your cart?');">
                                <input type="hidden" name="action" value="remove">
                                <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                                <button type="submit" class="action-button remove-button">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div class="checkout-section">
                <div class="total-price">Total: ₱<?= number_format($grandTotal, 2) ?></div>
                <button type="submit" class="checkout-button">Proceed to Checkout Selected Items</button>
            </div>
        </form>
    <?php endif; ?>

    <script>
        // Confirm before proceeding to checkout if no items are selected
        document.querySelector('form[action="checkout.php"]').addEventListener('submit', function(e) {
            const checkedBoxes = document.querySelectorAll('input[name="selected_items[]"]:checked');
            if (checkedBoxes.length === 0) {
                e.preventDefault();
                alert('Please select at least one item to checkout');
            }
        });
    </script>
</body>
</html>