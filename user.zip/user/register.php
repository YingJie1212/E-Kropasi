<?php
require_once "../classes/User.php";
require_once "../classes/DB.php";
session_start();

$db = new DB();
$user = new User($db);

$errors = [];
$profileImage = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile image upload
    if (!empty($_FILES['profile_image']['name'])) {
        $targetDir = "../uploads/";
        
        // Create upload directory if it doesn't exist
        if (!file_exists($targetDir)) {
            if (!mkdir($targetDir, 0777, true)) {
                $errors[] = "Failed to create upload directory.";
            }
        }
        
        // Check if directory is writable
        if (is_writable($targetDir)) {
            $fileName = basename($_FILES['profile_image']['name']);
            $targetFile = $targetDir . time() . "_" . $fileName;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            
            // Check if file is an actual image
            $check = getimagesize($_FILES['profile_image']['tmp_name']);
            if ($check === false) {
                $errors[] = "File is not an image.";
            }
            
            // Check file size (max 2MB)
            if ($_FILES['profile_image']['size'] > 2000000) {
                $errors[] = "Image must be less than 2MB in size.";
            }
            
            // Allow certain file formats
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($imageFileType, $allowedTypes)) {
                $errors[] = "Only JPG, JPEG, PNG & GIF files are allowed.";
            }
            
            // Upload file if no errors
            if (empty($errors)) {
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFile)) {
                    $profileImage = basename($targetFile); // Save filename only
                } else {
                    $errors[] = "Failed to upload profile image.";
                }
            }
        } else {
            $errors[] = "Upload directory is not writable.";
        }
    }

    $data = [
        'name' => isset($_POST['name']) ? trim($_POST['name']) : '',
        'student_id' => isset($_POST['student_id']) ? trim($_POST['student_id']) : '',
        'password' => isset($_POST['password']) ? $_POST['password'] : '',
        'class_name' => isset($_POST['class_name']) ? trim($_POST['class_name']) : '',
        'phone' => isset($_POST['phone']) ? trim($_POST['phone']) : '',
        'parent_name' => isset($_POST['parent_name']) ? trim($_POST['parent_name']) : '',
        'parent_phone' => isset($_POST['parent_phone']) ? trim($_POST['parent_phone']) : '',
        'profile_image' => $profileImage
    ];

    // Basic validation
    foreach ($data as $key => $value) {
        if ($key !== 'profile_image' && empty($value)) {
            $errors[] = ucfirst(str_replace('_', ' ', $key)) . " is required.";
        }
    }

    // Password strength validation
    $password = $data['password'];
    if (
        strlen($password) < 8 ||
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        $errors[] = "Password must be at least 8 characters long and include uppercase, lowercase, and a number.";
    }

    // Student ID uniqueness check
    if (empty($errors)) {
        if ($user->studentIdExists($data['student_id'])) {
            $errors[] = "That Student ID is already registered.";
        } else {
            if ($user->register($data)) {
                header("Location: login.php?registered=1");
                exit;
            } else {
                $errors[] = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- 省略头部，保持你原有代码 -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Student Registration</title>
     <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            padding: 30px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .header h1 {
            color: #333;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .header p {
            color: #666;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            color: #555;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #0066cc;
        }
        
        .form-group input::placeholder {
            color: #aaa;
        }
        
        .file-upload {
            border: 1px dashed #ddd;
            border-radius: 4px;
            padding: 15px;
            text-align: center;
            margin-bottom: 15px;
            cursor: pointer;
            transition: border-color 0.3s;
        }
        
        .file-upload:hover {
            border-color: #ccc;
        }
        
        .file-upload input {
            display: none;
        }
        
        .file-upload-text {
            font-size: 13px;
            color: #666;
            margin-top: 8px;
        }
        
        .preview-img {
            max-width: 80px;
            max-height: 80px;
            border-radius: 50%;
            margin-top: 10px;
            display: none;
        }
        
        .submit-btn {
            width: 100%;
            padding: 10px;
            background-color: #0066cc;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            background-color: #0052a3;
        }
        
        .footer-links {
            text-align: center;
            margin-top: 20px;
            font-size: 13px;
            color: #666;
        }
        
        .footer-links a {
            color: #0066cc;
            text-decoration: none;
        }
        
        .footer-links a:hover {
            text-decoration: underline;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 15px 0;
            color: #999;
            font-size: 13px;
        }
        
        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }
        
        .divider::before {
            margin-right: 10px;
        }
        
        .divider::after {
            margin-left: 10px;
        }
        
        .error-message {
            color: #e74c3c;
            font-size: 13px;
            margin-top: 5px;
        }
        
        .password-strength {
            height: 3px;
            background: #eee;
            margin-top: 6px;
            border-radius: 2px;
            overflow: hidden;
        }
        
        .strength-meter {
            height: 100%;
            width: 0;
            transition: width 0.3s, background 0.3s;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Student Portal</h1>
            <p>Register to access your dashboard</p>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div style="color: #e74c3c; margin-bottom: 15px; padding: 10px; background: #fdeded; border-radius: 4px; font-size: 13px;">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form action="register.php" method="post" enctype="multipart/form-data">
            <div class="file-upload" id="fileUploadContainer">
                <input type="file" id="profile_image" name="profile_image" accept="image/*" />
                <div>📷</div>
                <div class="file-upload-text">Click to upload profile photo</div>
                <img id="preview" class="preview-img" src="#" alt="Preview" />
            </div>

            <div class="form-group">
                <label for="student_id">Student ID</label>
                <input type="text" id="student_id" name="student_id" placeholder="Enter your student ID" required />
            </div>

            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required />
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required />
                <div class="password-strength">
                    <div class="strength-meter" id="strengthMeter"></div>
                </div>
            </div>

            <div class="form-group">
                <label for="class_name">Class Name</label>
                <input type="text" id="class_name" name="class_name" placeholder="Enter your class name" required />
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required />
            </div>

            <div class="form-group">
                <label for="parent_name">Parent's Name</label>
                <input type="text" id="parent_name" name="parent_name" placeholder="Enter your parent's name" required />
            </div>

            <div class="form-group">
                <label for="parent_phone">Parent's Phone Number</label>
                <input type="tel" id="parent_phone" name="parent_phone" placeholder="Enter your parent's phone number" required />
            </div>

            <button type="submit" class="submit-btn">Register</button>

            <div class="divider">or</div>

            <div class="footer-links">
                Already have an account? <a href="login.php">Login in</a>
            </div>
        </form>
    </div>

    <script>
        // Profile image upload preview
        const fileInput = document.getElementById('profile_image');
        const fileUploadContainer = document.getElementById('fileUploadContainer');
        const preview = document.getElementById('preview');
        
        fileUploadContainer.addEventListener('click', () => fileInput.click());
        
        fileInput.addEventListener('change', function() {
            if (fileInput.files && fileInput.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.style.display = 'block';
                    preview.src = e.target.result;
                }
                
                reader.readAsDataURL(fileInput.files[0]);
            }
        });
        
        // Password strength meter
        const passwordInput = document.getElementById('password');
        const strengthMeter = document.getElementById('strengthMeter');
        
        passwordInput.addEventListener('input', function() {
            const value = passwordInput.value;
            let strength = 0;
            
            if (value.length >= 8) strength += 1;
            if (/[A-Z]/.test(value)) strength += 1;
            if (/[0-9]/.test(value)) strength += 1;
            if (/[^A-Za-z0-9]/.test(value)) strength += 1;
            
            const width = (strength / 4) * 100;
            strengthMeter.style.width = width + '%';
            
            if (width < 50) {
                strengthMeter.style.backgroundColor = '#e74c3c';
            } else if (width < 75) {
                strengthMeter.style.backgroundColor = '#f39c12';
            } else {
                strengthMeter.style.backgroundColor = '#2ecc71';
            }
        });
    </script>
</body>
</html>
