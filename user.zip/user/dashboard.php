<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        :root {
            --primary-blue: #e6f2ff;
            --secondary-blue: #f0f8ff;
            --accent-blue: #b3d9ff;
            --text-color: #333;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--primary-blue);
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: white;
            box-shadow: var(--shadow);
            padding: 20px 0;
            margin-bottom: 30px;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        h2 {
            color: #0066cc;
            margin: 0;
            font-weight: 600;
        }
        
        .dashboard {
            display: grid;
            grid-template-columns: 250px 1fr;
            gap: 30px;
        }
        
        .sidebar {
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 20px;
        }
        
        .main-content {
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 30px;
        }
        
        .user-info {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--accent-blue);
        }
        
        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .nav-menu li {
            margin-bottom: 15px;
        }
        
        .nav-menu a {
            display: block;
            padding: 10px 15px;
            color: var(--text-color);
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            background-color: var(--accent-blue);
            color: #0066cc;
        }
        
        .nav-menu a.logout {
            color: #cc0000;
        }
        
        .nav-menu a.logout:hover {
            background-color: #ffebeb;
        }
        
        .info-card {
            background-color: var(--secondary-blue);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .info-card p {
            margin: 5px 0;
        }
        
        .label {
            font-weight: 600;
            color: #0066cc;
        }
    </style>
</head>
<body>
    <header>
        <div class="container header-content">
            <h2>Student Dashboard</h2>
        </div>
    </header>
    
    <div class="container">
        <div class="dashboard">
            <aside class="sidebar">
                <div class="user-info">
                    <h3>Welcome, <?= htmlspecialchars($_SESSION['name']) ?></h3>
                </div>
                
                <ul class="nav-menu">
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                </ul>
            </aside>
            
            <main class="main-content">
                <div class="info-card">
                    <p><span class="label">Student ID:</span> <?= htmlspecialchars($_SESSION['student_id']) ?></p>
                </div>
                
                <section>
                    <h3>Quick Actions</h3>
                    <p>Content sections can go here...</p>
                </section>
            </main>
        </div>
    </div>
</body>
</html>