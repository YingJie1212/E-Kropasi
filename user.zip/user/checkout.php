<?php
session_start();
require_once "../classes/Cart.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart = new Cart();

// Validate selected items
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['selected_items'])) {
    echo "<p>No items selected. <a href='cart.php'>Return to cart</a>.</p>";
    exit;
}

// Build selected items list
$selectedItemIds = array_map('intval', $_POST['selected_items']);
$allItems = $cart->getItemsByUser($user_id);

// Optional: handle "Remove from checkout"
if (isset($_POST['remove_id'])) {
    $removeId = (int) $_POST['remove_id'];
    $selectedItemIds = array_filter($selectedItemIds, fn($id) => $id !== $removeId);
}

// Filter only selected items
$checkoutItems = array_filter($allItems, fn($item) => in_array($item['id'], $selectedItemIds));

if (empty($checkoutItems)) {
    echo "<p>No items left in checkout. <a href='cart.php'>Return to cart</a>.</p>";
    exit;
}

// Handle total
$total = 0;
foreach ($checkoutItems as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout - Edit Options</title>
    <style>
        :root {
            --primary-beige: #f5f5f0;
            --secondary-beige: #e8e6df;
            --accent-beige: #d8d5cd;
            --text-color: #333;
            --border-color: #c4beb5;
            --button-color: #8b7d70;
            --button-hover: #6b5d52;
            --remove-color: #c45656;
            --remove-hover: #a33d3d;
            --confirm-color: #5a8f5a;
            --confirm-hover: #487a48;
            --header-bg: #e8e6df;
            --row-even: #f9f8f6;
            --row-odd: #ffffff;
            --highlight-color: #f0e6d2;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--primary-beige);
            color: var(--text-color);
            line-height: 1.6;
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        h1 {
            font-weight: 500;
            color: #5a4e42;
            font-size: 28px;
        }
        
        .back-link {
            color: var(--button-color);
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s;
        }
        
        .back-link:hover {
            color: var(--button-hover);
            text-decoration: underline;
        }
        
        .checkout-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .checkout-table th {
            background-color: var(--header-bg);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #5a4e42;
            border-bottom: 2px solid var(--border-color);
        }
        
        .checkout-table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }
        
        .checkout-table tr:nth-child(even) {
            background-color: var(--row-even);
        }
        
        .checkout-table tr:nth-child(odd) {
            background-color: var(--row-odd);
        }
        
        .checkout-table tr:hover {
            background-color: var(--highlight-color);
        }
        
        .product-info {
            display: flex;
            align-items: flex-start;
            gap: 15px;
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }
        
        .product-name {
            font-weight: 600;
            color: #5a4e42;
            margin-bottom: 5px;
        }
        
        .product-type {
            font-size: 12px;
            color: #8b7d70;
            margin-left: 5px;
        }
        
        .option-group {
            margin-bottom: 10px;
        }
        
        .option-label {
            display: block;
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 3px;
            color: #5a4e42;
        }
        
        .option-select {
            width: 100%;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            font-size: 13px;
        }
        
        .quantity-input {
            width: 70px;
            padding: 6px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            text-align: center;
        }
        
        .action-button {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .action-button:hover {
            background-color: var(--button-hover);
        }
        
        .remove-button {
            background-color: var(--remove-color);
        }
        
        .remove-button:hover {
            background-color: var(--remove-hover);
        }
        
        .total-section {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }
        
        .total-price {
            font-size: 18px;
            font-weight: 600;
            color: #5a4e42;
        }
        
        .confirm-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
        }
        
        .confirm-button {
            background-color: var(--confirm-color);
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: 500;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .confirm-button:hover {
            background-color: var(--confirm-hover);
        }
        
        .product-option-title {
            font-weight: 500;
            margin: 8px 0 4px;
            color: #5a4e42;
        }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Checkout - Edit Options</h1>
        <a href="cart.php" class="back-link">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Back to Cart
        </a>
    </div>

    <form method="POST" action="place_order.php">
        <table class="checkout-table">
            <thead>
                <tr>
                    <th style="width: 30%;">Product</th>
                    <th style="width: 35%;">Options</th>
                    <th style="width: 100px;">Quantity</th>
                    <th style="width: 100px;">Subtotal</th>
                    <th style="width: 100px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($checkoutItems as $item): ?>
                    <tr>
                        <td>
                            <div class="product-info">
                                <?php if (!empty($item['display_images'])): ?>
                                    <img src="../uploads/<?= htmlspecialchars($item['display_images'][0]) ?>" class="product-image">
                                <?php else: ?>
                                    <img src="../assets/default.jpg" class="product-image">
                                <?php endif; ?>
                                <div>
                                    <div class="product-name">
                                        <?= htmlspecialchars($item['display_name']) ?>
                                        <span class="product-type">(<?= $item['item_type'] ?>)</span>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php
                            $selected = $item['selected_options'] ?? [];

                            if ($item['item_type'] === 'product') {
                                $optionGroups = $cart->getOptionGroupsWithValues($item['item_id']);
                                foreach ($optionGroups as $group):
                                    $groupName = $group['group_name'];
                                    $selectedId = $selected[$groupName] ?? null;
                            ?>
                                <div class="option-group">
                                    <label class="option-label"><?= htmlspecialchars($groupName) ?></label>
                                    <select class="option-select" name="options[<?= $item['id'] ?>][<?= htmlspecialchars($groupName) ?>]">
                                        <?php foreach ($group['options'] as $opt): ?>
                                            <option value="<?= $opt['id'] ?>" <?= $opt['id'] == $selectedId ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($opt['value']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endforeach; ?>
                            <?php } elseif ($item['item_type'] === 'package') {
                                $packageOptions = $cart->getOptionsForPackage($item['item_id']);
                                foreach ($packageOptions as $product_id => $product):
                            ?>
                                <div class="product-option-title"><?= htmlspecialchars($product['product_name']) ?></div>
                                <?php
                                    foreach ($product['option_groups'] as $group):
                                        $groupName = $group['group_name'];
                                        $selectedId = $selected[$product_id][$groupName] ?? null;
                                ?>
                                    <div class="option-group">
                                        <label class="option-label"><?= htmlspecialchars($groupName) ?></label>
                                        <select class="option-select" name="options[<?= $item['id'] ?>][<?= $product_id ?>][<?= htmlspecialchars($groupName) ?>]">
                                            <?php foreach ($group['options'] as $opt): ?>
                                                <option value="<?= $opt['id'] ?>" <?= $opt['id'] == $selectedId ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($opt['value']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endforeach; endforeach; } ?>
                        </td>
                        <td>
                            <input type="number" class="quantity-input" name="quantities[<?= $item['id'] ?>]" value="<?= $item['quantity'] ?>" min="1">
                        </td>
                        <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        <td>
                            <form method="POST" action="checkout.php" onsubmit="return confirm('Remove this item from checkout?');">
                                <input type="hidden" name="remove_id" value="<?= $item['id'] ?>">
                                <?php foreach ($selectedItemIds as $id): ?>
                                    <?php if ($id != $item['id']): ?>
                                        <input type="hidden" name="selected_items[]" value="<?= $id ?>">
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <button type="submit" class="action-button remove-button">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total-section">
            <div class="total-price">Total: ₱<?= number_format($total, 2) ?></div>
        </div>

        <div class="confirm-section">
            <a href="cart.php" class="back-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
                Back to Cart
            </a>
            <div>
                <?php foreach ($selectedItemIds as $id): ?>
                    <input type="hidden" name="selected_items[]" value="<?= $id ?>">
                <?php endforeach; ?>
                <button type="submit" class="confirm-button">Place Order</button>
            </div>
        </div>
    </form>
</body>
</html>