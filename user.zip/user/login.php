<?php
require_once "../classes/DB.php";
require_once "../classes/User.php";
session_start();

$db = new DB();
$user = new User($db);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id']);
    $password = $_POST['password'];

    if (empty($student_id) || empty($password)) {
        $errors[] = "Both Student ID and Password are required.";
    } else {
        $loggedInUser = $user->login($student_id, $password);
        if ($loggedInUser) {
            $_SESSION['user_id'] = $loggedInUser['id'];
            $_SESSION['student_id'] = $loggedInUser['student_id'];
            $_SESSION['name'] = $loggedInUser['name'];

            header("Location: dashboard.php");
            exit;
        } else {
            $errors[] = "Invalid Student ID or Password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal Login</title>
    <style>
        :root {
            --primary-light-green: #e8f5e9;
            --secondary-light-yellow: #fff9c4;
            --accent-green: #81c784;
            --text-dark: #2e7d32;
            --error-red: #d32f2f;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--primary-light-green);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 420px;
        }
        
        .login-header {
            background-color: var(--secondary-light-yellow);
            padding: 30px 20px;
            text-align: center;
            border-bottom: 4px solid var(--accent-green);
        }
        
        .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            background-color: var(--accent-green);
            border-radius: 50%;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .login-header h1 {
            color: var(--text-dark);
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .login-header p {
            color: #666;
            font-size: 14px;
        }
        
        .login-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-dark);
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--accent-green);
            outline: none;
            box-shadow: 0 0 0 3px rgba(129, 199, 132, 0.2);
        }
        
        .btn {
            background-color: var(--accent-green);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }
        
        .btn:hover {
            background-color: #66bb6a;
        }
        
        .error {
            color: var(--error-red);
            background-color: #ffebee;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .error ul {
            list-style-type: none;
        }
        
        .error li {
            margin-bottom: 5px;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .login-footer a {
            color: var(--text-dark);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .login-footer a:hover {
            color: var(--accent-green);
            text-decoration: underline;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #999;
            font-size: 14px;
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }
        
        .divider::before {
            margin-right: 10px;
        }
        
        .divider::after {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">SP</div>
            <h1>Student Portal</h1>
            <p>Sign in to access your dashboard</p>
        </div>
        
        <div class="login-form">
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <ul>
                        <?php foreach ($errors as $e): ?>
                            <li><?= htmlspecialchars($e) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input type="text" class="form-control" id="student_id" name="student_id" placeholder="Enter your student ID" value="<?= htmlspecialchars($_POST['student_id'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
                </div>
                
                <button type="submit" class="btn">Login</button>
            </form>
            
            <div class="divider">or</div>
            
            <div class="login-footer">
                <p><a href="forgot_password.php">Forgot your password?</a></p>
                <p>Don't have an account? <a href="register.php">Register here</a></p>
            </div>
        </div>
    </div>
</body>
</html>