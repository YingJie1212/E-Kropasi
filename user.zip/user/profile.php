<?php
require_once "../classes/DB.php";
require_once "../classes/User.php";
session_start();

// Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit;
}

$db = new DB();
$user = new User($db);

// Get student info
$student = $user->getByStudentId($_SESSION['student_id']);

if (!$student) {
    echo "User not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <style>
        :root {
            --ice-blue: #f5faff;
            --soft-blue: #e1f0ff;
            --medium-blue: #a8d0ff;
            --dark-blue: #4a89dc;
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--ice-blue);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .profile-card {
            width: 100%;
            max-width: 480px;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            margin: 20px;
        }
        
        .profile-header {
            background-color: var(--soft-blue);
            padding: 30px;
            text-align: center;
            position: relative;
        }
        
        .profile-title {
            margin: 0;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .avatar-container {
            margin: 20px auto;
            position: relative;
            width: 140px;
            height: 140px;
        }
        
        .profile-avatar {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            background-color: var(--medium-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3rem;
            font-weight: bold;
        }
        
        .profile-content {
            padding: 30px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .info-label {
            font-weight: 500;
            color: var(--dark-blue);
            text-align: right;
            padding-right: 10px;
        }
        
        .info-value {
            font-weight: 400;
            color: var(--text-dark);
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            justify-content: center;
        }
        
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
            display: inline-block;
        }
        
        .btn-primary {
            background-color: var(--dark-blue);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #3a70c2;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(74, 137, 220, 0.3);
        }
        
        .btn-secondary {
            background-color: white;
            color: var(--dark-blue);
            border: 1px solid var(--medium-blue);
        }
        
        .btn-secondary:hover {
            background-color: var(--soft-blue);
            transform: translateY(-2px);
        }
        
        .no-image {
            font-size: 0.9rem;
            color: var(--text-light);
            font-style: italic;
        }
        
        @media (max-width: 500px) {
            .info-grid {
                grid-template-columns: 1fr;
                gap: 5px;
            }
            
            .info-label {
                text-align: left;
                padding-right: 0;
                margin-top: 10px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="profile-card">
        <div class="profile-header">
            <h1 class="profile-title"><?= htmlspecialchars($student['name']) ?></h1>
            <div class="avatar-container">
                <?php if (!empty($student['profile_image'])): ?>
                    <img src="../uploads/<?= htmlspecialchars($student['profile_image']) ?>" alt="Profile Image" class="profile-avatar">
                <?php else: ?>
                    <div class="profile-avatar"><?= strtoupper(substr($student['name'], 0, 1)) ?></div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="profile-content">
            <div class="info-grid">
                <span class="info-label">Student ID:</span>
                <span class="info-value"><?= htmlspecialchars($student['student_id']) ?></span>
                
                <span class="info-label">Class:</span>
                <span class="info-value"><?= htmlspecialchars($student['class_name']) ?></span>
                
                <span class="info-label">Phone:</span>
                <span class="info-value"><?= htmlspecialchars($student['phone']) ?></span>
                
                <span class="info-label">Parent's Name:</span>
                <span class="info-value"><?= htmlspecialchars($student['parent_name']) ?></span>
                
                <span class="info-label">Parent's Phone:</span>
                <span class="info-value"><?= htmlspecialchars($student['parent_phone']) ?></span>
            </div>
            
            <div class="action-buttons">
                <a href="edit_profile.php" class="btn btn-primary">Edit Profile</a>
                <a href="logout.php" class="btn btn-secondary">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>