<?php
session_start();
require_once "../classes/Cart.php";
require_once "../classes/DB.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart = new Cart();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['selected_items'])) {
    echo "<p>No items selected. <a href='cart.php'>Return to cart</a>.</p>";
    exit;
}

$selectedItemIds = array_map('intval', $_POST['selected_items']);
$allItems = $cart->getItemsByUser($user_id);

$orderItems = array_filter($allItems, function ($item) use ($selectedItemIds) {
    return in_array($item['id'], $selectedItemIds);
});

if (empty($orderItems)) {
    echo "<p>No valid items found. <a href='cart.php'>Return to cart</a>.</p>";
    exit;
}

$totalAmount = 0;
foreach ($orderItems as $item) {
    $totalAmount += $item['price'] * $item['quantity'];
}

$shipping_address = "School Pickup";

try {
    $pdo = $cart->getConnection(); // This method should return $this->conn from DB class
    $pdo->beginTransaction();

    // Get user info (student name and class)
    $stmtUser = $pdo->prepare("SELECT name, class_name FROM users WHERE id = ?");
    $stmtUser->execute([$user_id]);
    $userInfo = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$userInfo) {
        throw new Exception("User not found.");
    }

    // Insert order
    $stmtOrder = $pdo->prepare("
        INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at, student_name, class_name)
        VALUES (?, ?, 'Pending', ?, NOW(), ?, ?)
    ");
    $stmtOrder->execute([
        $user_id,
        $totalAmount,
        $shipping_address,
        $userInfo['name'],
        $userInfo['class_name']
    ]);

    $order_id = $pdo->lastInsertId();

    // Insert items
    $stmtItem = $pdo->prepare("
        INSERT INTO order_items (order_id, product_id, package_id, quantity, price, selected_options)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    foreach ($orderItems as $item) {
        $product_id = $item['item_type'] === 'product' ? $item['item_id'] : null;
        $package_id = $item['item_type'] === 'package' ? $item['item_id'] : null;
        $quantity = $item['quantity'];
        $price = $item['price'];
        $selected_options = json_encode($item['selected_options'] ?? []);

        $stmtItem->execute([
            $order_id,
            $product_id,
            $package_id,
            $quantity,
            $price,
            $selected_options
        ]);

        $cart->removeItem($item['id'], $user_id);
    }

    $pdo->commit();
    $success = true;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Receipt</title>
    <style>
        :root {
            --primary-beige: #f5f5f0;
            --secondary-beige: #e8e6df;
            --accent-beige: #d8d5cd;
            --text-color: #333;
            --border-color: #c4beb5;
            --success-color: #5a8f5a;
            --error-color: #c45656;
            --header-bg: #e8e6df;
            --row-even: #f9f8f6;
            --row-odd: #ffffff;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--primary-beige);
            color: var(--text-color);
            line-height: 1.6;
            padding: 30px;
        }
        
        .receipt-container {
            max-width: 700px;
            margin: 0 auto;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        
        .receipt-header {
            text-align: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .receipt-title {
            font-size: 24px;
            font-weight: 600;
            color: var(--success-color);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .receipt-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .receipt-meta-item {
            flex: 1;
            min-width: 150px;
        }
        
        .receipt-meta-label {
            font-size: 13px;
            color: #8b7d70;
            margin-bottom: 3px;
        }
        
        .receipt-meta-value {
            font-weight: 500;
            color: #5a4e42;
        }
        
        .receipt-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .receipt-table th {
            background-color: var(--header-bg);
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
            color: #5a4e42;
            border-bottom: 2px solid var(--border-color);
        }
        
        .receipt-table td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }
        
        .receipt-table tr:nth-child(even) {
            background-color: var(--row-even);
        }
        
        .receipt-table tr:nth-child(odd) {
            background-color: var(--row-odd);
        }
        
        .receipt-total {
            text-align: right;
            font-size: 18px;
            font-weight: 600;
            color: #5a4e42;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color);
        }
        
        .receipt-note {
            text-align: center;
            font-style: italic;
            color: #8b7d70;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px dashed var(--border-color);
        }
        
        .receipt-error {
            color: var(--error-color);
            text-align: center;
            margin: 20px 0;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--button-color);
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s;
        }
        
        .back-link:hover {
            color: var(--button-hover);
            text-decoration: underline;
        }
        
        .option-value {
            font-size: 13px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="receipt-container">
        <?php if (!empty($success)): ?>
            <div class="receipt-header">
                <h1 class="receipt-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    Order Receipt
                </h1>
            </div>
            
            <div class="receipt-meta">
                <div class="receipt-meta-item">
                    <div class="receipt-meta-label">Order ID</div>
                    <div class="receipt-meta-value"><?= htmlspecialchars($order_id) ?></div>
                </div>
                <div class="receipt-meta-item">
                    <div class="receipt-meta-label">Date</div>
                    <div class="receipt-meta-value"><?= date("Y-m-d H:i:s") ?></div>
                </div>
                <div class="receipt-meta-item">
                    <div class="receipt-meta-label">Student Name</div>
                    <div class="receipt-meta-value"><?= htmlspecialchars($userInfo['name']) ?></div>
                </div>
                <div class="receipt-meta-item">
                    <div class="receipt-meta-label">Class</div>
                    <div class="receipt-meta-value"><?= htmlspecialchars($userInfo['class_name']) ?></div>
                </div>
            </div>
            
            <table class="receipt-table">
                <thead>
                    <tr>
                        <th style="width: 30%;">Item</th>
                        <th style="width: 10%;">Qty</th>
                        <th style="width: 30%;">Options</th>
                        <th style="width: 15%;">Price</th>
                        <th style="width: 15%;">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orderItems as $item): ?>
                        <tr>
                            <td>
                                <div style="font-weight: 500;"><?= htmlspecialchars($item['display_name']) ?></div>
                                <div style="font-size: 12px; color: #8b7d70;">
                                    <?= $item['item_type'] === 'product' ? 'Product' : 'Package' ?>
                                </div>
                            </td>
                            <td><?= $item['quantity'] ?></td>
                            <td>
                                <?php
                                    $options = $item['selected_options'];
                                    if (is_array($options) && count($options) > 0) {
                                        foreach ($options as $key => $value) {
                                            if (is_array($value)) {
                                                foreach ($value as $subKey => $subValue) {
                                                    echo '<div class="option-value">' . htmlspecialchars("$subKey: $subValue") . '</div>';
                                                }
                                            } else {
                                                echo '<div class="option-value">' . htmlspecialchars("$key: $value") . '</div>';
                                            }
                                        }
                                    } else {
                                        echo '<div class="option-value">-</div>';
                                    }
                                ?>
                            </td>
                            <td>₱<?= number_format($item['price'], 2) ?></td>
                            <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="receipt-total">
                <strong>Total Amount:</strong> ₱<?= number_format($totalAmount, 2) ?>
            </div>
            
            <div class="receipt-note">
                Please present this receipt upon pickup at the school canteen.
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="products.php" class="back-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M19 12H5M12 19l-7-7 7-7"/>
                    </svg>
                    Back to Products
                </a>
            </div>
            
        <?php else: ?>
            <div class="receipt-header">
                <h1 class="receipt-title" style="color: var(--error-color);">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    Order Failed
                </h1>
            </div>
            
            <div class="receipt-error">
                <p><?= htmlspecialchars($error ?? "Unknown error occurred") ?></p>
            </div>
            
            <div style="text-align: center;">
                <a href="cart.php" class="back-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M19 12H5M12 19l-7-7 7-7"/>
                    </svg>
                    Return to Cart
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>