<?php
require_once "../classes/DB.php";
require_once "../classes/User.php";

$db = new DB();
$user = new User($db);

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($student_id) || empty($new_password) || empty($confirm_password)) {
        $errors[] = "All fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    } elseif (
        strlen($new_password) < 8 ||
        !preg_match('/[A-Z]/', $new_password) ||
        !preg_match('/[a-z]/', $new_password) ||
        !preg_match('/[0-9]/', $new_password)
    ) {
        $errors[] = "Password must be at least 8 characters long and include uppercase, lowercase, and a number.";
    } elseif (!$user->studentIdExists($student_id)) {
        $errors[] = "Student ID not found.";
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        if ($user->updatePassword($student_id, $hashed)) {
            $success = true;
        } else {
            $errors[] = "Failed to reset password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Student Portal</title>
    <style>
        :root {
            --primary-light-green: #e8f5e9;
            --secondary-light-yellow: #fff9c4;
            --accent-green: #81c784;
            --text-dark: #2e7d32;
            --error-red: #d32f2f;
            --success-green: #388e3c;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--primary-light-green);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .reset-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 420px;
        }
        
        .reset-header {
            background-color: var(--secondary-light-yellow);
            padding: 30px 20px;
            text-align: center;
            border-bottom: 4px solid var(--accent-green);
        }
        
        .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            background-color: var(--accent-green);
            border-radius: 50%;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .reset-header h1 {
            color: var(--text-dark);
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .reset-header p {
            color: #666;
            font-size: 14px;
        }
        
        .reset-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-dark);
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--accent-green);
            outline: none;
            box-shadow: 0 0 0 3px rgba(129, 199, 132, 0.2);
        }
        
        .btn {
            background-color: var(--accent-green);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }
        
        .btn:hover {
            background-color: #66bb6a;
        }
        
        .error {
            color: var(--error-red);
            background-color: #ffebee;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .error ul {
            list-style-type: none;
        }
        
        .error li {
            margin-bottom: 5px;
        }
        
        .success {
            color: var(--success-green);
            background-color: #e8f5e9;
            padding: 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 16px;
            text-align: center;
        }
        
        .success a {
            color: var(--success-green);
            font-weight: 600;
            text-decoration: none;
        }
        
        .success a:hover {
            text-decoration: underline;
        }
        
        .reset-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .reset-footer a {
            color: var(--text-dark);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .reset-footer a:hover {
            color: var(--accent-green);
            text-decoration: underline;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #999;
            font-size: 14px;
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }
        
        .divider::before {
            margin-right: 10px;
        }
        
        .divider::after {
            margin-left: 10px;
        }
        
        .password-requirements {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="reset-header">
            <div class="logo">SP</div>
            <h1>Reset Password</h1>
            <p>Enter your student ID and new password</p>
        </div>
        
        <div class="reset-form">
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <ul>
                        <?php foreach ($errors as $e): ?>
                            <li><?= htmlspecialchars($e) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success">
                    Password reset successfully. <a href="login.php">Login now</a>
                </div>
            <?php else: ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="student_id">Student ID</label>
                        <input type="text" class="form-control" id="student_id" name="student_id" placeholder="Enter your student ID" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Enter your new password" required>
                        <div class="password-requirements">Must be 8+ characters with uppercase, lowercase, and a number</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your new password" required>
                    </div>
                    
                    <button type="submit" class="btn">Reset Password</button>
                </form>
                
                <div class="divider">or</div>
                
                <div class="reset-footer">
                    <p>Remember your password? <a href="login.php">Login here</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>